'''
Recursive Function
'''
##
# Define function named factorial 
# @param n
# The base case is n <= 1: return 1
# else @var result = n * factorial(n - 1) This is the recursive call
# return result

#enter syntax here


n = 5
#Call factorial function and pass n as the argument

#enter syntax here

